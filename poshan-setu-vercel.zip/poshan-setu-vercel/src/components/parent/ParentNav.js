import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const tabs = [
  { key: 'meals',    label: 'nav_meals',   path: '/parent/home',     icon: MealsIcon },
  { key: 'notices',  label: 'nav_notices', path: '/parent/notices',  icon: NoticeIcon },
  { key: 'settings', label: 'settings',   path: '/parent/settings', icon: SettingsIcon },
];

export default function ParentNav({ active }) {
  const { t } = useTranslation();
  const navigate = useNavigate();
  return (
    <nav style={styles.nav}>
      {tabs.map(({ key, label, path, icon: Icon }) => (
        <button key={key} style={styles.tab} onClick={() => navigate(path)}>
          <Icon active={active === key} />
          <span style={{ ...styles.tabLabel, color: active === key ? '#1D9E75' : '#9CA3AF' }}>
            {t(label)}
          </span>
        </button>
      ))}
    </nav>
  );
}

function MealsIcon({ active }) {
  const c = active ? '#1D9E75' : '#9CA3AF';
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <rect x="3" y="11" width="4" height="8" rx="1" fill={c} opacity={active ? 1 : 0.5} />
      <rect x="9" y="7" width="4" height="12" rx="1" fill={c} opacity={active ? 1 : 0.7} />
      <rect x="15" y="3" width="4" height="16" rx="1" fill={c} />
    </svg>
  );
}

function NoticeIcon({ active }) {
  const c = active ? '#1D9E75' : '#9CA3AF';
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <rect x="3" y="4" width="16" height="14" rx="3" stroke={c} strokeWidth="1.5" />
      <path d="M7 9h8M7 13h5" stroke={c} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function SettingsIcon({ active }) {
  const c = active ? '#1D9E75' : '#9CA3AF';
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <circle cx="11" cy="11" r="3" stroke={c} strokeWidth="1.5" />
      <path d="M11 2v2M11 18v2M2 11h2M18 11h2M4.93 4.93l1.41 1.41M15.66 15.66l1.41 1.41M4.93 17.07l1.41-1.41M15.66 6.34l1.41-1.41" stroke={c} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

const styles = {
  nav: { position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)', width: '100%', maxWidth: 480, background: '#fff', borderTop: '1px solid #E5E7EB', display: 'flex', padding: '8px 0 12px', zIndex: 100 },
  tab: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, background: 'none', border: 'none', cursor: 'pointer', padding: 0 },
  tabLabel: { fontSize: 10, fontWeight: 600 },
};
