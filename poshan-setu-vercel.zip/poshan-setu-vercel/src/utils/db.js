// ============================================================
//  Poshan Setu — in-browser "database"
//  All data is stored in localStorage so it persists across
//  page reloads but needs no server or external DB.
// ============================================================

import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

const KEYS = {
  admins:   'ps_admins',
  parents:  'ps_parents',
  children: 'ps_children',
  meals:    'ps_meals',
  tips:     'ps_tips',
  notices:  'ps_notices',
  logs:     'ps_reminder_logs',
};

// ── helpers ──────────────────────────────────────────────
const load  = (k) => JSON.parse(localStorage.getItem(k) || '[]');
const save  = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const nowTs = () => new Date().toISOString();

// ── seed ─────────────────────────────────────────────────
const SEEDED_KEY = 'ps_seeded_v2';

export function seedDatabase() {
  if (localStorage.getItem(SEEDED_KEY)) return;

  // Admin — password "password"
  const adminHash = '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
  save(KEYS.admins, [{
    id: 'admin-1',
    name: 'NGO Admin',
    email: 'admin@brightfutureindia.org',
    password_hash: adminHash,
    created_at: nowTs(),
  }]);

  // Sample parents (password "parent123")
  const parentHash = '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhu4';
  const parents = [
    { id: 'parent-1', name: 'Sunita Jadhav',  phone: '9876543210', password_hash: parentHash, language_preference: 'mr', reminders_enabled: true,  created_at: nowTs() },
    { id: 'parent-2', name: 'Ramesh Sharma',  phone: '9123456780', password_hash: parentHash, language_preference: 'hi', reminders_enabled: true,  created_at: nowTs() },
    { id: 'parent-3', name: 'Priya Kulkarni', phone: '9012345678', password_hash: parentHash, language_preference: 'en', reminders_enabled: false, created_at: nowTs() },
  ];
  save(KEYS.parents, parents);

  const children = [
    { id: 'child-1', name: 'Aarav Jadhav',   class: '5', age: 10, parent_id: 'parent-1', created_at: nowTs() },
    { id: 'child-2', name: 'Meera Sharma',   class: '3', age: 8,  parent_id: 'parent-2', created_at: nowTs() },
    { id: 'child-3', name: 'Rohit Kulkarni', class: '6', age: 11, parent_id: 'parent-3', created_at: nowTs() },
  ];
  save(KEYS.children, children);

  // Meals for this week
  const today = new Date();
  const meals = [];
  const mealTemplates = [
    { meal_name: 'Dal khichdi + sabzi',     nutritional_flag: 'good' },
    { meal_name: 'Rice + rajma',            nutritional_flag: 'good' },
    { meal_name: 'Chapati + dal',           nutritional_flag: 'low_iron' },
    { meal_name: 'Poha + banana',           nutritional_flag: 'good' },
    { meal_name: 'Rice + plain dal',        nutritional_flag: 'low_protein' },
  ];
  for (let daysAgo = 4; daysAgo >= 0; daysAgo--) {
    const d = new Date(today);
    d.setDate(d.getDate() - daysAgo);
    const dateStr = d.toISOString().split('T')[0];
    children.forEach((child, ci) => {
      const tmpl = mealTemplates[(ci + daysAgo) % mealTemplates.length];
      meals.push({
        id: uuidv4(),
        child_id: child.id,
        date: dateStr,
        meal_name: tmpl.meal_name,
        nutritional_flag: tmpl.nutritional_flag,
        notes: '',
        logged_by: 'admin-1',
        created_at: nowTs(),
      });
    });
  }
  save(KEYS.meals, meals);

  save(KEYS.tips, [
    { id: 'tip-1', content_en: 'Make sure your child eats breakfast every morning. Even a banana and a glass of milk helps them focus better in school.', content_mr: 'आपल्या मुलाने दररोज सकाळी नाश्ता करावा याची खात्री करा. केळी आणि एक ग्लास दूध देखील शाळेत लक्ष केंद्रित करण्यास मदत करते.', content_hi: 'सुनिश्चित करें कि आपका बच्चा हर सुबह नाश्ता करे। एक केला और एक गिलास दूध भी उन्हें स्कूल में बेहतर ध्यान केंद्रित करने में मदद करता है।', active: true },
    { id: 'tip-2', content_en: 'Include dal or eggs in your child\'s meals for protein. Protein helps muscles grow and keeps energy levels high throughout the day.', content_mr: 'प्रथिनांसाठी आपल्या मुलाच्या जेवणात डाळ किंवा अंडी समाविष्ट करा. प्रथिने स्नायूंच्या वाढीस मदत करतात.', content_hi: 'प्रोटीन के लिए अपने बच्चे के भोजन में दाल या अंडे शामिल करें। प्रोटीन मांसपेशियों को बढ़ने में मदद करता है।', active: true },
    { id: 'tip-3', content_en: 'Green vegetables like spinach and methi are rich in iron. Iron prevents anaemia and keeps your child active and alert.', content_mr: 'पालक आणि मेथीसारख्या हिरव्या भाज्यांमध्ये लोह भरपूर असते. लोह अॅनिमिया टाळते.', content_hi: 'पालक और मेथी जैसी हरी सब्जियां आयरन से भरपूर होती हैं। आयरन एनीमिया को रोकता है।', active: true },
    { id: 'tip-4', content_en: 'Avoid giving children too much street food. It can contain harmful bacteria and lacks the nutrition their growing bodies need.', content_mr: 'मुलांना जास्त रस्त्यावरील खाणे देणे टाळा. त्यात हानिकारक जीवाणू असू शकतात.', content_hi: 'बच्चों को बहुत अधिक स्ट्रीट फूड देने से बचें। इसमें हानिकारक बैक्टीरिया हो सकते हैं।', active: true },
    { id: 'tip-5', content_en: 'Make sure your child drinks enough water throughout the day. Dehydration causes tiredness and makes it hard to concentrate.', content_mr: 'आपल्या मुलाने दिवसभर पुरेसे पाणी प्यावे याची खात्री करा. निर्जलीकरणामुळे थकवा येतो.', content_hi: 'सुनिश्चित करें कि आपका बच्चा दिन भर पर्याप्त पानी पिए। निर्जलीकरण से थकान होती है।', active: true },
  ]);

  save(KEYS.notices, [{
    id: 'notice-1',
    title_en: 'Health check-up on 10 April',
    title_mr: '10 एप्रिल रोजी आरोग्य तपासणी',
    title_hi: '10 अप्रैल को स्वास्थ्य जांच',
    body_en: 'All children will have a free health check-up on 10 April at the NGO centre. Please ensure your child attends school that day.',
    body_mr: 'सर्व मुलांची 10 एप्रिल रोजी एनजीओ केंद्रात मोफत आरोग्य तपासणी होईल. कृपया आपल्या मुलाने त्या दिवशी शाळेत यावे याची खात्री करा.',
    body_hi: 'सभी बच्चों की 10 अप्रैल को एनजीओ केंद्र में मुफ्त स्वास्थ्य जांच होगी। कृपया सुनिश्चित करें कि आपका बच्चा उस दिन स्कूल जाए।',
    created_by: 'admin-1',
    created_at: nowTs(),
  }]);

  save(KEYS.logs, []);
  localStorage.setItem(SEEDED_KEY, '1');
}

// ── Auth ─────────────────────────────────────────────────

export async function loginParent(phone, password) {
  const parents = load(KEYS.parents);
  const parent = parents.find(p => p.phone === phone);
  if (!parent) throw new Error('Invalid phone or password');
  const valid = await bcrypt.compare(password, parent.password_hash);
  if (!valid) throw new Error('Invalid phone or password');
  return {
    id: parent.id, name: parent.name, phone: parent.phone,
    language: parent.language_preference, remindersEnabled: parent.reminders_enabled,
    role: 'parent',
  };
}

export async function loginAdmin(email, password) {
  const admins = load(KEYS.admins);
  const admin = admins.find(a => a.email === email);
  if (!admin) throw new Error('Invalid email or password');
  const valid = await bcrypt.compare(password, admin.password_hash);
  if (!valid) throw new Error('Invalid email or password');
  return { id: admin.id, name: admin.name, email: admin.email, role: 'admin' };
}

// ── Parent APIs ──────────────────────────────────────────

export function getParentProfile(parentId) {
  const parents = load(KEYS.parents);
  const parent = parents.find(p => p.id === parentId);
  if (!parent) return null;
  const children = load(KEYS.children).filter(c => c.parent_id === parentId);
  return { ...parent, children };
}

export function updateParentSettings(parentId, { language, remindersEnabled }) {
  const parents = load(KEYS.parents);
  const idx = parents.findIndex(p => p.id === parentId);
  if (idx === -1) return;
  parents[idx].language_preference = language;
  parents[idx].reminders_enabled = remindersEnabled;
  save(KEYS.parents, parents);
}

export function getParentMeals(parentId) {
  const children = load(KEYS.children).filter(c => c.parent_id === parentId);
  if (!children.length) return [];
  const childIds = children.map(c => c.id);
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay()); // Sunday
  weekStart.setHours(0, 0, 0, 0);
  const meals = load(KEYS.meals).filter(m =>
    childIds.includes(m.child_id) && new Date(m.date) >= weekStart && new Date(m.date) <= now
  );
  return meals.sort((a, b) => b.date.localeCompare(a.date));
}

export function getTodayTip(lang) {
  const tips = load(KEYS.tips).filter(t => t.active);
  if (!tips.length) return { content: 'Eat a balanced meal every day!' };
  const tip = tips[Math.floor(Math.random() * tips.length)];
  const col = ['en', 'mr', 'hi'].includes(lang) ? lang : 'en';
  return { id: tip.id, content: tip[`content_${col}`] };
}

export function getNotices(lang) {
  const suffix = ['en', 'mr', 'hi'].includes(lang) ? lang : 'en';
  return load(KEYS.notices)
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .slice(0, 10)
    .map(n => ({
      id: n.id,
      title: n[`title_${suffix}`],
      body: n[`body_${suffix}`],
      created_at: n.created_at,
    }));
}

// ── Admin APIs ───────────────────────────────────────────

export function getStats() {
  const children = load(KEYS.children);
  const parents = load(KEYS.parents);
  const today = new Date().toISOString().split('T')[0];
  const meals = load(KEYS.meals).filter(m => m.date === today);
  const remindersActive = parents.filter(p => p.reminders_enabled).length;
  return {
    totalChildren: children.length,
    totalParents: parents.length,
    mealsLoggedToday: meals.length,
    remindersActive,
  };
}

export function getAllChildren() {
  const children = load(KEYS.children);
  const parents = load(KEYS.parents);
  return children.map(c => {
    const p = parents.find(par => par.id === c.parent_id) || {};
    return {
      ...c,
      parent_name: p.name, phone: p.phone,
      language_preference: p.language_preference,
      reminders_enabled: p.reminders_enabled,
      parent_id: p.id,
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
}

export async function addChild({ childName, childClass, childAge, parentName, parentPhone, parentPassword }) {
  const parents = load(KEYS.parents);
  if (parents.find(p => p.phone === parentPhone)) throw new Error('Phone number already registered');
  const hash = await bcrypt.hash(parentPassword, 10);
  const parentId = uuidv4();
  parents.push({ id: parentId, name: parentName, phone: parentPhone, password_hash: hash, language_preference: 'en', reminders_enabled: true, created_at: nowTs() });
  save(KEYS.parents, parents);
  const children = load(KEYS.children);
  const child = { id: uuidv4(), name: childName, class: childClass, age: parseInt(childAge), parent_id: parentId, created_at: nowTs() };
  children.push(child);
  save(KEYS.children, children);
  return child;
}

export function logMeal({ childId, date, mealName, nutritionalFlag, notes, adminId }) {
  const meals = load(KEYS.meals);
  const idx = meals.findIndex(m => m.child_id === childId && m.date === date);
  const meal = { id: idx >= 0 ? meals[idx].id : uuidv4(), child_id: childId, date, meal_name: mealName, nutritional_flag: nutritionalFlag || 'good', notes: notes || '', logged_by: adminId, created_at: nowTs() };
  if (idx >= 0) meals[idx] = meal; else meals.push(meal);
  save(KEYS.meals, meals);
  return meal;
}

export function getMealsByDate(date) {
  const meals = load(KEYS.meals).filter(m => m.date === date);
  const children = load(KEYS.children);
  return meals.map(m => {
    const c = children.find(ch => ch.id === m.child_id) || {};
    return { ...m, child_name: c.name, class: c.class };
  }).sort((a, b) => (a.child_name || '').localeCompare(b.child_name || ''));
}

export function addNotice({ titleEn, titleMr, titleHi, bodyEn, bodyMr, bodyHi, adminId }) {
  const notices = load(KEYS.notices);
  const notice = { id: uuidv4(), title_en: titleEn, title_mr: titleMr || '', title_hi: titleHi || '', body_en: bodyEn, body_mr: bodyMr || '', body_hi: bodyHi || '', created_by: adminId, created_at: nowTs() };
  notices.unshift(notice);
  save(KEYS.notices, notices);
  return notice;
}

export function toggleParentReminder(parentId, enabled) {
  const parents = load(KEYS.parents);
  const idx = parents.findIndex(p => p.id === parentId);
  if (idx !== -1) { parents[idx].reminders_enabled = enabled; save(KEYS.parents, parents); }
}
