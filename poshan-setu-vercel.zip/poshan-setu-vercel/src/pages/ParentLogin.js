import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { loginParent } from '../utils/db';
import i18n from '../i18n';

export default function ParentLogin() {
  const { t } = useTranslation();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await loginParent(phone, password);
      i18n.changeLanguage(user.language || 'en');
      localStorage.setItem('ps_lang', user.language || 'en');
      login(user);
      navigate('/parent/home');
    } catch {
      setError(t('login_error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.logoWrap}><div style={styles.logo}>🌱</div></div>
        <h1 style={styles.title}>{t('login_title')}</h1>
        <p style={styles.subtitle}>{t('login_subtitle')}</p>

        <div style={styles.langRow}>
          {['en', 'mr', 'hi'].map((l) => (
            <button
              key={l}
              style={{ ...styles.langBtn, ...(i18n.language === l ? styles.langBtnActive : {}) }}
              onClick={() => { i18n.changeLanguage(l); localStorage.setItem('ps_lang', l); }}
            >
              {l === 'en' ? 'English' : l === 'mr' ? 'मराठी' : 'हिंदी'}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          <label style={styles.label}>{t('phone_label')}</label>
          <input style={styles.input} type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="9876543210" required />
          <label style={styles.label}>{t('password_label')}</label>
          <input style={styles.input} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
          {error && <p style={styles.error}>{error}</p>}
          <button style={styles.btn} type="submit" disabled={loading}>{loading ? '…' : t('login_btn')}</button>
        </form>

        <div style={styles.demoBox}>
          <p style={styles.demoTitle}>Demo logins</p>
          <p style={styles.demoRow}>📱 <b>9876543210</b> / parent123 (Marathi)</p>
          <p style={styles.demoRow}>📱 <b>9123456780</b> / parent123 (Hindi)</p>
          <p style={styles.demoRow}>📱 <b>9012345678</b> / parent123 (English)</p>
        </div>

        <p style={styles.adminLink}>
          NGO Staff?{' '}
          <span style={styles.link} onClick={() => navigate('/admin/login')}>Admin login</span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 },
  card: { background: '#fff', borderRadius: 20, padding: '32px 28px', width: '100%', maxWidth: 380, boxShadow: '0 4px 24px rgba(15,110,86,0.10)' },
  logoWrap: { textAlign: 'center', marginBottom: 8 },
  logo: { fontSize: 48 },
  title: { textAlign: 'center', fontSize: 26, fontWeight: 700, color: '#085041', margin: '0 0 4px' },
  subtitle: { textAlign: 'center', fontSize: 14, color: '#0F6E56', margin: '0 0 20px' },
  langRow: { display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 24 },
  langBtn: { padding: '5px 14px', borderRadius: 99, border: '1px solid #9FE1CB', background: '#fff', color: '#0F6E56', fontSize: 13, cursor: 'pointer' },
  langBtnActive: { background: '#1D9E75', color: '#fff', border: '1px solid #1D9E75' },
  form: { display: 'flex', flexDirection: 'column', gap: 10 },
  label: { fontSize: 13, fontWeight: 600, color: '#374151' },
  input: { padding: '11px 14px', borderRadius: 10, border: '1px solid #D1FAE5', fontSize: 15, outline: 'none', color: '#111' },
  error: { color: '#DC2626', fontSize: 13, margin: 0 },
  btn: { marginTop: 6, padding: '13px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: 'pointer' },
  demoBox: { marginTop: 20, background: '#F0FDF4', borderRadius: 12, padding: '12px 14px', border: '1px solid #D1FAE5' },
  demoTitle: { fontSize: 11, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 },
  demoRow: { fontSize: 12, color: '#374151', marginBottom: 3 },
  adminLink: { textAlign: 'center', fontSize: 13, color: '#6B7280', marginTop: 16 },
  link: { color: '#1D9E75', cursor: 'pointer', fontWeight: 600 },
};
