import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getNotices } from '../utils/db';
import ParentNav from '../components/parent/ParentNav';

export default function ParentNotices() {
  const { t } = useTranslation();
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const lang = localStorage.getItem('ps_lang') || 'en';

  useEffect(() => {
    setNotices(getNotices(lang));
    setLoading(false);
  }, [lang]);

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h2 style={styles.title}>{t('notices')}</h2>
        <p style={styles.sub}>From Bright Future India</p>
      </div>
      <div style={styles.body}>
        {loading ? (
          <p style={styles.muted}>{t('loading')}</p>
        ) : notices.length === 0 ? (
          <p style={styles.muted}>No notices at the moment.</p>
        ) : (
          notices.map((n) => (
            <div key={n.id} style={styles.card}>
              <div style={styles.dot} />
              <div style={{ flex: 1 }}>
                <p style={styles.noticeTitle}>{n.title}</p>
                <p style={styles.noticeBody}>{n.body}</p>
                <p style={styles.time}>
                  {new Date(n.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'long' })}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
      <ParentNav active="notices" />
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#f0fdf4', display: 'flex', flexDirection: 'column', maxWidth: 480, margin: '0 auto' },
  header: { background: '#1D9E75', padding: '20px 20px 28px' },
  title: { color: '#fff', fontSize: 20, fontWeight: 700, margin: 0 },
  sub: { color: '#9FE1CB', fontSize: 13, margin: '4px 0 0' },
  body: { flex: 1, padding: '20px 16px 80px' },
  card: { background: '#fff', borderRadius: 14, padding: '14px 16px', marginBottom: 12, display: 'flex', gap: 12, boxShadow: '0 1px 6px rgba(0,0,0,0.05)' },
  dot: { width: 10, height: 10, borderRadius: '50%', background: '#1D9E75', flexShrink: 0, marginTop: 5 },
  noticeTitle: { fontWeight: 700, fontSize: 14, color: '#111827', margin: '0 0 6px' },
  noticeBody: { fontSize: 13, color: '#374151', lineHeight: 1.6, margin: '0 0 8px' },
  time: { fontSize: 12, color: '#9CA3AF', margin: 0 },
  muted: { color: '#9CA3AF', fontSize: 14 },
};
