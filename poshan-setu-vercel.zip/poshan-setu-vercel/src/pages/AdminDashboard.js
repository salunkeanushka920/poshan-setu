import React, { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  getStats, getAllChildren, addChild,
  logMeal, getMealsByDate, addNotice, toggleParentReminder,
} from '../utils/db';

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [stats, setStats]     = useState(null);
  const [children, setChildren] = useState([]);
  const [meals, setMeals]     = useState([]);
  const [activeTab, setActiveTab] = useState('overview');

  const [mealForm, setMealForm] = useState({
    childId: '', date: new Date().toISOString().split('T')[0],
    mealName: '', nutritionalFlag: 'good', notes: '',
  });
  const [mealMsg, setMealMsg] = useState('');

  const [childForm, setChildForm] = useState({
    childName: '', childClass: '', childAge: '',
    parentName: '', parentPhone: '', parentPassword: '',
  });
  const [childMsg, setChildMsg] = useState('');

  const [noticeForm, setNoticeForm] = useState({
    titleEn: '', bodyEn: '', titleMr: '', bodyMr: '', titleHi: '', bodyHi: '',
  });
  const [noticeMsg, setNoticeMsg] = useState('');

  const refresh = useCallback(() => {
    setStats(getStats());
    setChildren(getAllChildren());
    setMeals(getMealsByDate(new Date().toISOString().split('T')[0]));
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const handleLogMeal = (e) => {
    e.preventDefault();
    try {
      logMeal({ ...mealForm, adminId: user.id });
      setMealMsg('✅ Meal logged successfully!');
      setMeals(getMealsByDate(mealForm.date));
      setStats(getStats());
      setTimeout(() => setMealMsg(''), 3000);
    } catch (err) {
      setMealMsg('Error: ' + err.message);
    }
  };

  const handleAddChild = async (e) => {
    e.preventDefault();
    try {
      await addChild(childForm);
      setChildMsg('✅ Child added successfully!');
      setChildren(getAllChildren());
      setStats(getStats());
      setChildForm({ childName: '', childClass: '', childAge: '', parentName: '', parentPhone: '', parentPassword: '' });
      setTimeout(() => setChildMsg(''), 3000);
    } catch (err) {
      setChildMsg('Error: ' + err.message);
    }
  };

  const handleAddNotice = (e) => {
    e.preventDefault();
    try {
      addNotice({ ...noticeForm, adminId: user.id });
      setNoticeMsg('✅ Notice posted!');
      setNoticeForm({ titleEn: '', bodyEn: '', titleMr: '', bodyMr: '', titleHi: '', bodyHi: '' });
      setTimeout(() => setNoticeMsg(''), 3000);
    } catch {
      setNoticeMsg('Error posting notice');
    }
  };

  const handleToggleReminder = (parentId, current) => {
    toggleParentReminder(parentId, !current);
    setChildren(getAllChildren());
  };

  const FLAG_COLORS = {
    good: '#D1FAE5', low_protein: '#FEF3C7',
    low_iron: '#FEF3C7', low_vitamins: '#FEF3C7', poor: '#FEE2E2',
  };

  const tabs = ['overview', 'log-meal', 'children', 'notices'];
  const tabLabels = { overview: '📊 Overview', 'log-meal': '🍽 Log Meal', children: '👧 Children', notices: '📢 Notices' };

  return (
    <div style={s.page}>
      {/* Sidebar */}
      <div style={s.sidebar}>
        <div style={s.logo}>🌱 Poshan Setu</div>
        <p style={s.adminName}>{user?.name}</p>
        {tabs.map((tab) => (
          <button key={tab} style={{ ...s.navBtn, ...(activeTab === tab ? s.navBtnActive : {}) }} onClick={() => setActiveTab(tab)}>
            {tabLabels[tab]}
          </button>
        ))}
        <button style={s.logoutBtn} onClick={logout}>Logout</button>
      </div>

      {/* Main content */}
      <div style={s.main}>

        {/* ── Overview ── */}
        {activeTab === 'overview' && (
          <>
            <h2 style={s.pageTitle}>Overview</h2>
            <div style={s.statsGrid}>
              {stats && [
                ['Total children',     stats.totalChildren,     '#D1FAE5', '#065F46'],
                ['Total parents',      stats.totalParents,      '#DBEAFE', '#1E40AF'],
                ['Meals logged today', stats.mealsLoggedToday,  '#FEF3C7', '#92400E'],
                ['Reminders active',   stats.remindersActive,   '#EDE9FE', '#4C1D95'],
              ].map(([label, val, bg, color]) => (
                <div key={label} style={{ ...s.statCard, background: bg }}>
                  <p style={{ ...s.statNum, color }}>{val}</p>
                  <p style={{ ...s.statLabel, color }}>{label}</p>
                </div>
              ))}
            </div>

            <h3 style={s.subTitle}>Today's meals</h3>
            {meals.length === 0 ? (
              <p style={s.muted}>No meals logged today yet.</p>
            ) : (
              <div style={s.table}>
                <div style={s.thead}>
                  <span style={s.th}>Child</span>
                  <span style={s.th}>Class</span>
                  <span style={s.th}>Meal</span>
                  <span style={s.th}>Status</span>
                </div>
                {meals.map((m) => (
                  <div key={m.id} style={s.trow}>
                    <span style={s.td}>{m.child_name}</span>
                    <span style={s.td}>{m.class}</span>
                    <span style={s.td}>{m.meal_name}</span>
                    <span style={s.td}>
                      <span style={{ background: FLAG_COLORS[m.nutritional_flag] || '#fff', padding: '2px 10px', borderRadius: 99, fontSize: 12 }}>
                        {m.nutritional_flag}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ── Log Meal ── */}
        {activeTab === 'log-meal' && (
          <>
            <h2 style={s.pageTitle}>Log a meal</h2>
            <form onSubmit={handleLogMeal} style={s.form}>
              <label style={s.label}>Child</label>
              <select style={s.input} value={mealForm.childId} onChange={(e) => setMealForm({ ...mealForm, childId: e.target.value })} required>
                <option value="">Select child</option>
                {children.map((c) => <option key={c.id} value={c.id}>{c.name} (Class {c.class})</option>)}
              </select>

              <label style={s.label}>Date</label>
              <input style={s.input} type="date" value={mealForm.date} onChange={(e) => setMealForm({ ...mealForm, date: e.target.value })} required />

              <label style={s.label}>Meal name</label>
              <input style={s.input} type="text" placeholder="e.g. Dal khichdi + vegetables" value={mealForm.mealName} onChange={(e) => setMealForm({ ...mealForm, mealName: e.target.value })} required />

              <label style={s.label}>Nutritional status</label>
              <select style={s.input} value={mealForm.nutritionalFlag} onChange={(e) => setMealForm({ ...mealForm, nutritionalFlag: e.target.value })}>
                <option value="good">Good — balanced meal</option>
                <option value="low_protein">Low protein</option>
                <option value="low_iron">Low iron</option>
                <option value="low_vitamins">Low vitamins</option>
                <option value="poor">Poor — needs improvement</option>
              </select>

              <label style={s.label}>Notes (optional)</label>
              <input style={s.input} type="text" placeholder="Any notes…" value={mealForm.notes} onChange={(e) => setMealForm({ ...mealForm, notes: e.target.value })} />

              {mealMsg && <p style={{ color: mealMsg.startsWith('Error') ? '#DC2626' : '#065F46', fontSize: 13 }}>{mealMsg}</p>}
              <button style={s.btn} type="submit">Log meal</button>
            </form>
          </>
        )}

        {/* ── Children ── */}
        {activeTab === 'children' && (
          <>
            <h2 style={s.pageTitle}>Children &amp; parents</h2>
            <div style={s.table}>
              <div style={s.thead}>
                <span style={s.th}>Child</span>
                <span style={s.th}>Class / Age</span>
                <span style={s.th}>Parent</span>
                <span style={s.th}>Phone</span>
                <span style={s.th}>Reminders</span>
              </div>
              {children.map((c) => (
                <div key={c.id} style={s.trow}>
                  <span style={s.td}>{c.name}</span>
                  <span style={s.td}>Class {c.class}, Age {c.age}</span>
                  <span style={s.td}>{c.parent_name}</span>
                  <span style={s.td}>{c.phone}</span>
                  <span style={s.td}>
                    <div
                      style={{ ...s.toggle, background: c.reminders_enabled ? '#1D9E75' : '#D1D5DB' }}
                      onClick={() => handleToggleReminder(c.parent_id, c.reminders_enabled)}
                    >
                      <div style={{ ...s.toggleThumb, transform: c.reminders_enabled ? 'translateX(18px)' : 'translateX(2px)' }} />
                    </div>
                  </span>
                </div>
              ))}
            </div>

            <h3 style={{ ...s.subTitle, marginTop: 32 }}>Add new child</h3>
            <form onSubmit={handleAddChild} style={s.form}>
              <div style={s.formGrid}>
                {[
                  ['childName', 'Child name', 'text'],
                  ['childClass', 'Class', 'text'],
                  ['childAge', 'Age', 'number'],
                  ['parentName', 'Parent name', 'text'],
                  ['parentPhone', 'Parent phone', 'tel'],
                  ['parentPassword', 'Initial password', 'password'],
                ].map(([key, label, type]) => (
                  <div key={key}>
                    <label style={s.label}>{label}</label>
                    <input style={s.input} type={type} value={childForm[key]} onChange={(e) => setChildForm({ ...childForm, [key]: e.target.value })} required />
                  </div>
                ))}
              </div>
              {childMsg && <p style={{ color: childMsg.startsWith('Error') ? '#DC2626' : '#065F46', fontSize: 13 }}>{childMsg}</p>}
              <button style={s.btn} type="submit">Add child</button>
            </form>
          </>
        )}

        {/* ── Notices ── */}
        {activeTab === 'notices' && (
          <>
            <h2 style={s.pageTitle}>Post a notice</h2>
            <form onSubmit={handleAddNotice} style={s.form}>
              {[
                ['English', 'titleEn', 'bodyEn'],
                ['Marathi (मराठी)', 'titleMr', 'bodyMr'],
                ['Hindi (हिंदी)', 'titleHi', 'bodyHi'],
              ].map(([langLabel, titleKey, bodyKey]) => (
                <div key={langLabel}>
                  <p style={{ fontWeight: 600, fontSize: 14, color: '#374151', margin: '16px 0 8px' }}>{langLabel}</p>
                  <label style={s.label}>Title</label>
                  <input style={s.input} type="text" value={noticeForm[titleKey]} onChange={(e) => setNoticeForm({ ...noticeForm, [titleKey]: e.target.value })} required={titleKey === 'titleEn'} />
                  <label style={{ ...s.label, marginTop: 8 }}>Message</label>
                  <textarea style={{ ...s.input, height: 80, resize: 'vertical' }} value={noticeForm[bodyKey]} onChange={(e) => setNoticeForm({ ...noticeForm, [bodyKey]: e.target.value })} required={bodyKey === 'bodyEn'} />
                </div>
              ))}
              {noticeMsg && <p style={{ color: noticeMsg.startsWith('Error') ? '#DC2626' : '#065F46', fontSize: 13 }}>{noticeMsg}</p>}
              <button style={s.btn} type="submit">Post notice</button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

const s = {
  page: { display: 'flex', minHeight: '100vh', background: '#F8FAFC', fontFamily: 'system-ui, sans-serif' },
  sidebar: { width: 220, background: '#fff', borderRight: '1px solid #E2E8F0', padding: '24px 16px', display: 'flex', flexDirection: 'column', gap: 4, flexShrink: 0 },
  logo: { fontSize: 18, fontWeight: 700, color: '#085041', marginBottom: 8 },
  adminName: { fontSize: 13, color: '#6B7280', marginBottom: 16 },
  navBtn: { padding: '10px 14px', borderRadius: 10, border: 'none', background: 'transparent', textAlign: 'left', fontSize: 14, color: '#374151', cursor: 'pointer', fontWeight: 500 },
  navBtnActive: { background: '#D1FAE5', color: '#065F46', fontWeight: 700 },
  logoutBtn: { marginTop: 'auto', padding: '10px 14px', borderRadius: 10, border: '1px solid #FCA5A5', background: 'transparent', color: '#DC2626', cursor: 'pointer', fontSize: 14, fontWeight: 600 },
  main: { flex: 1, padding: '32px', overflowY: 'auto' },
  pageTitle: { fontSize: 22, fontWeight: 700, color: '#0F172A', marginBottom: 24 },
  subTitle: { fontSize: 16, fontWeight: 700, color: '#0F172A', marginBottom: 12 },
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 },
  statCard: { borderRadius: 14, padding: '16px 20px' },
  statNum: { fontSize: 32, fontWeight: 700, margin: '0 0 4px' },
  statLabel: { fontSize: 13, fontWeight: 500, margin: 0 },
  table: { background: '#fff', borderRadius: 14, overflow: 'hidden', border: '1px solid #E2E8F0' },
  thead: { display: 'flex', background: '#F1F5F9', padding: '10px 16px', gap: 16 },
  th: { flex: 1, fontSize: 12, fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: 0.5 },
  trow: { display: 'flex', padding: '12px 16px', gap: 16, borderTop: '1px solid #F1F5F9', alignItems: 'center' },
  td: { flex: 1, fontSize: 13, color: '#374151' },
  form: { background: '#fff', borderRadius: 14, padding: '20px 24px', border: '1px solid #E2E8F0', display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 600 },
  formGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 16px' },
  label: { fontSize: 12, fontWeight: 600, color: '#374151', marginBottom: 3, display: 'block' },
  input: { width: '100%', padding: '10px 12px', borderRadius: 8, border: '1px solid #E2E8F0', fontSize: 14, color: '#111', boxSizing: 'border-box', outline: 'none' },
  btn: { marginTop: 8, padding: '12px 24px', background: '#1D9E75', color: '#fff', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: 'pointer', alignSelf: 'flex-start' },
  toggle: { width: 40, height: 22, borderRadius: 11, position: 'relative', cursor: 'pointer', transition: 'background .2s' },
  toggleThumb: { position: 'absolute', top: 2, width: 18, height: 18, borderRadius: '50%', background: '#fff', transition: 'transform .2s' },
  muted: { color: '#9CA3AF', fontSize: 14 },
};
