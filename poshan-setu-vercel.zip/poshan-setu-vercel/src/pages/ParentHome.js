import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { getParentMeals, getTodayTip } from '../utils/db';
import ParentNav from '../components/parent/ParentNav';

const FLAG_STYLES = {
  good:         { bg: '#D1FAE5', color: '#065F46', label: 'flag_good' },
  low_protein:  { bg: '#FEF3C7', color: '#92400E', label: 'flag_low_protein' },
  low_iron:     { bg: '#FEF3C7', color: '#92400E', label: 'flag_low_iron' },
  low_vitamins: { bg: '#FEF3C7', color: '#92400E', label: 'flag_low_vitamins' },
  poor:         { bg: '#FEE2E2', color: '#991B1B', label: 'flag_poor' },
};

const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

export default function ParentHome() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [meals, setMeals] = useState([]);
  const [tip, setTip] = useState('');
  const [loading, setLoading] = useState(true);
  const lang = localStorage.getItem('ps_lang') || 'en';

  useEffect(() => {
    if (user?.id) {
      const m = getParentMeals(user.id);
      setMeals(m);
      const tipData = getTodayTip(lang);
      setTip(tipData?.content || '');
    }
    setLoading(false);
  }, [user, lang]);

  const childName = user?.children?.[0]?.name || user?.name;

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div>
          <p style={styles.greeting}>{t('greeting')}, {user?.name?.split(' ')[0]} ji</p>
          <p style={styles.subGreeting}>{childName}'s school meals</p>
        </div>
        <div style={styles.avatar}>{user?.name?.charAt(0)}</div>
      </div>

      <div style={styles.body}>
        {loading ? (
          <p style={styles.muted}>{t('loading')}</p>
        ) : (
          <>
            <p style={styles.sectionLabel}>{t('meals_this_week')}</p>
            <div style={styles.mealCard}>
              {meals.length === 0 ? (
                <p style={{ ...styles.muted, padding: '12px 0' }}>{t('no_meals')}</p>
              ) : (
                meals.map((m) => {
                  const flag = FLAG_STYLES[m.nutritional_flag] || FLAG_STYLES.good;
                  const day = DAYS[new Date(m.date + 'T12:00:00').getDay()];
                  return (
                    <div key={m.date} style={styles.mealRow}>
                      <span style={styles.mealDay}>{day}</span>
                      <span style={styles.mealName}>{m.meal_name}</span>
                      <span style={{ ...styles.badge, background: flag.bg, color: flag.color }}>{t(flag.label)}</span>
                    </div>
                  );
                })
              )}
            </div>
            {tip && (
              <>
                <p style={styles.sectionLabel}>{t('tip_of_day')}</p>
                <div style={styles.tipCard}>
                  <span style={styles.tipIcon}>💡</span>
                  <p style={styles.tipText}>{tip}</p>
                </div>
              </>
            )}
          </>
        )}
      </div>
      <ParentNav active="meals" />
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#f0fdf4', display: 'flex', flexDirection: 'column', maxWidth: 480, margin: '0 auto' },
  header: { background: '#1D9E75', padding: '20px 20px 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' },
  greeting: { color: '#fff', fontSize: 20, fontWeight: 700, margin: 0 },
  subGreeting: { color: '#9FE1CB', fontSize: 13, margin: '4px 0 0' },
  avatar: { width: 40, height: 40, borderRadius: '50%', background: 'rgba(255,255,255,0.25)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700 },
  body: { flex: 1, padding: '20px 16px 80px' },
  sectionLabel: { fontSize: 11, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10, marginTop: 4 },
  mealCard: { background: '#fff', borderRadius: 14, padding: '4px 14px', marginBottom: 20, boxShadow: '0 1px 6px rgba(0,0,0,0.05)' },
  mealRow: { display: 'flex', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #F0FDF4' },
  mealDay: { width: 36, fontSize: 12, color: '#9CA3AF', fontWeight: 600 },
  mealName: { flex: 1, fontSize: 14, color: '#111827', paddingRight: 8 },
  badge: { fontSize: 11, padding: '3px 9px', borderRadius: 99, fontWeight: 600, whiteSpace: 'nowrap' },
  tipCard: { background: '#EEF2FF', borderRadius: 14, padding: '14px 16px', display: 'flex', gap: 10, alignItems: 'flex-start' },
  tipIcon: { fontSize: 20, flexShrink: 0 },
  tipText: { fontSize: 13, color: '#3730A3', lineHeight: 1.6, margin: 0 },
  muted: { color: '#9CA3AF', fontSize: 14 },
};
