import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { loginAdmin } from '../utils/db';

export default function AdminLogin() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await loginAdmin(email, password);
      login(user);
      navigate('/admin/dashboard');
    } catch {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.badge}>NGO Staff Portal</div>
        <h1 style={styles.title}>Poshan Setu</h1>
        <p style={styles.subtitle}>Admin Dashboard</p>
        <form onSubmit={handleSubmit} style={styles.form}>
          <label style={styles.label}>Email</label>
          <input style={styles.input} type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@brightfutureindia.org" required />
          <label style={styles.label}>Password</label>
          <input style={styles.input} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
          {error && <p style={styles.error}>{error}</p>}
          <button style={styles.btn} type="submit" disabled={loading}>{loading ? '…' : 'Login'}</button>
        </form>
        <p style={styles.parentLink}>
          Parent?{' '}
          <span style={styles.link} onClick={() => navigate('/')}>Parent login</span>
        </p>
        <p style={styles.hint}>admin@brightfutureindia.org / password</p>
      </div>
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 },
  card: { background: '#fff', borderRadius: 20, padding: '32px 28px', width: '100%', maxWidth: 380, boxShadow: '0 4px 24px rgba(24,95,165,0.10)' },
  badge: { display: 'inline-block', background: '#DBEAFE', color: '#1E40AF', fontSize: 11, fontWeight: 700, padding: '4px 12px', borderRadius: 99, marginBottom: 16, letterSpacing: 0.5 },
  title: { fontSize: 26, fontWeight: 700, color: '#1E3A5F', margin: '0 0 4px' },
  subtitle: { fontSize: 14, color: '#3B82F6', margin: '0 0 24px' },
  form: { display: 'flex', flexDirection: 'column', gap: 10 },
  label: { fontSize: 13, fontWeight: 600, color: '#374151' },
  input: { padding: '11px 14px', borderRadius: 10, border: '1px solid #DBEAFE', fontSize: 15, outline: 'none', color: '#111' },
  error: { color: '#DC2626', fontSize: 13, margin: 0 },
  btn: { marginTop: 6, padding: 13, background: '#1D4ED8', color: '#fff', border: 'none', borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: 'pointer' },
  parentLink: { textAlign: 'center', fontSize: 13, color: '#6B7280', marginTop: 20 },
  link: { color: '#1D4ED8', cursor: 'pointer', fontWeight: 600 },
  hint: { textAlign: 'center', fontSize: 11, color: '#9CA3AF', marginTop: 10 },
};
