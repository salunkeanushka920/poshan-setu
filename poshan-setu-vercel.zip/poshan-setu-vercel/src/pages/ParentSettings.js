import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { updateParentSettings } from '../utils/db';
import ParentNav from '../components/parent/ParentNav';
import i18n from '../i18n';

export default function ParentSettings() {
  const { t } = useTranslation();
  const { user, login, logout } = useAuth();
  const [lang, setLang] = useState(localStorage.getItem('ps_lang') || 'en');
  const [reminders, setReminders] = useState(user?.remindersEnabled ?? true);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  const save = async () => {
    setLoading(true);
    try {
      updateParentSettings(user.id, { language: lang, remindersEnabled: reminders });
      i18n.changeLanguage(lang);
      localStorage.setItem('ps_lang', lang);
      login({ ...user, language: lang, remindersEnabled: reminders });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h2 style={styles.title}>{t('settings')}</h2>
      </div>
      <div style={styles.body}>
        <p style={styles.sectionLabel}>{t('language')}</p>
        <div style={styles.langRow}>
          {[['en', 'English'], ['mr', 'मराठी'], ['hi', 'हिंदी']].map(([code, label]) => (
            <button
              key={code}
              style={{ ...styles.langBtn, ...(lang === code ? styles.langBtnActive : {}) }}
              onClick={() => setLang(code)}
            >
              {label}
            </button>
          ))}
        </div>

        <p style={{ ...styles.sectionLabel, marginTop: 24 }}>{t('reminders')}</p>
        <div style={styles.toggleCard}>
          <div style={{ flex: 1 }}>
            <p style={styles.toggleTitle}>WhatsApp reminders</p>
            <p style={styles.toggleDesc}>{t('reminders_desc')}</p>
          </div>
          <div
            style={{ ...styles.toggle, background: reminders ? '#1D9E75' : '#D1D5DB' }}
            onClick={() => setReminders(!reminders)}
          >
            <div style={{ ...styles.toggleThumb, transform: reminders ? 'translateX(20px)' : 'translateX(2px)' }} />
          </div>
        </div>

        {saved && <p style={styles.successMsg}>{t('settings_saved')}</p>}

        <button style={styles.saveBtn} onClick={save} disabled={loading}>
          {loading ? '…' : t('save_settings')}
        </button>

        <button style={styles.logoutBtn} onClick={logout}>
          {t('logout')}
        </button>
      </div>
      <ParentNav active="settings" />
    </div>
  );
}

const styles = {
  page: { minHeight: '100vh', background: '#f0fdf4', display: 'flex', flexDirection: 'column', maxWidth: 480, margin: '0 auto' },
  header: { background: '#1D9E75', padding: '20px 20px 28px' },
  title: { color: '#fff', fontSize: 20, fontWeight: 700, margin: 0 },
  body: { flex: 1, padding: '20px 16px 80px' },
  sectionLabel: { fontSize: 11, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 },
  langRow: { display: 'flex', gap: 10 },
  langBtn: { flex: 1, padding: '10px', borderRadius: 10, border: '1.5px solid #D1FAE5', background: '#fff', color: '#0F6E56', fontSize: 14, cursor: 'pointer', fontWeight: 600 },
  langBtnActive: { background: '#1D9E75', color: '#fff', border: '1.5px solid #1D9E75' },
  toggleCard: { background: '#fff', borderRadius: 14, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 14, boxShadow: '0 1px 6px rgba(0,0,0,0.05)' },
  toggleTitle: { fontWeight: 600, fontSize: 14, color: '#111827', margin: '0 0 4px' },
  toggleDesc: { fontSize: 12, color: '#6B7280', margin: 0, lineHeight: 1.5 },
  toggle: { width: 44, height: 26, borderRadius: 13, position: 'relative', cursor: 'pointer', flexShrink: 0, transition: 'background .2s' },
  toggleThumb: { position: 'absolute', top: 3, width: 20, height: 20, borderRadius: '50%', background: '#fff', transition: 'transform .2s' },
  successMsg: { color: '#065F46', background: '#D1FAE5', borderRadius: 8, padding: '10px 14px', fontSize: 13, fontWeight: 600, marginTop: 16 },
  saveBtn: { width: '100%', marginTop: 24, padding: 14, background: '#1D9E75', color: '#fff', border: 'none', borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: 'pointer' },
  logoutBtn: { width: '100%', marginTop: 10, padding: 14, background: 'transparent', color: '#DC2626', border: '1.5px solid #FCA5A5', borderRadius: 12, fontSize: 15, fontWeight: 600, cursor: 'pointer' },
};
