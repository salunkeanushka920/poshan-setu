import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { seedDatabase } from './utils/db';
import './i18n';

import ParentLogin    from './pages/ParentLogin';
import ParentHome     from './pages/ParentHome';
import ParentNotices  from './pages/ParentNotices';
import ParentSettings from './pages/ParentSettings';
import AdminLogin     from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';

function PrivateRoute({ children, role }) {
  const { user, loading } = useAuth();
  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: '#6B7280' }}>Loading…</div>;
  if (!user) return <Navigate to={role === 'admin' ? '/admin/login' : '/'} replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  useEffect(() => { seedDatabase(); }, []);

  return (
    <Routes>
      <Route path="/"               element={<ParentLogin />} />
      <Route path="/parent/home"    element={<PrivateRoute role="parent"><ParentHome /></PrivateRoute>} />
      <Route path="/parent/notices" element={<PrivateRoute role="parent"><ParentNotices /></PrivateRoute>} />
      <Route path="/parent/settings"element={<PrivateRoute role="parent"><ParentSettings /></PrivateRoute>} />
      <Route path="/admin/login"    element={<AdminLogin />} />
      <Route path="/admin/dashboard"element={<PrivateRoute role="admin"><AdminDashboard /></PrivateRoute>} />
      <Route path="*"               element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
