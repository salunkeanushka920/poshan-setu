# Poshan Setu — Vercel-Ready Build

**No database. No backend. No environment variables needed.**  
Just download → deploy → done.

---

## 🚀 Deploy to Vercel in 3 steps

### Step 1 — Push to GitHub
1. Go to [github.com](https://github.com) → New repository → name it `poshan-setu`
2. Extract this zip on your computer
3. Open Terminal / Command Prompt in the extracted folder and run:
```
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/poshan-setu.git
git push -u origin main
```

### Step 2 — Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign in (free account)
2. Click **"Add New Project"**
3. Import your `poshan-setu` GitHub repository
4. Vercel will auto-detect it as a React app (Create React App)
5. **No environment variables needed** — leave everything as default
6. Click **Deploy**

### Step 3 — Done! 🎉
Your app is live at `https://poshan-setu.vercel.app` (or similar)

---

## 🔑 Login credentials

### Admin (NGO Staff)
- URL: `yoursite.vercel.app/admin/login`
- Email: `admin@brightfutureindia.org`
- Password: `password`

### Parent (demo accounts, pre-seeded)
- URL: `yoursite.vercel.app`
- Phone: `9876543210` / Password: `parent123` (Marathi — Sunita Jadhav)
- Phone: `9123456780` / Password: `parent123` (Hindi — Ramesh Sharma)
- Phone: `9012345678` / Password: `parent123` (English — Priya Kulkarni)

---

## 💾 How data works

All data is stored in the **browser's localStorage** — no server or database needed.

- Data **persists** across page refreshes ✅
- Each browser/device has its own separate data ✅
- Adding children, logging meals, posting notices — all saved locally ✅
- WhatsApp reminders are UI-only in this version (no Twilio calls) ✅

---

## 📱 Features

### Parent app (mobile)
- Login with phone + password (3 language options: English / मराठी / हिंदी)
- View child's school meals for the week with nutritional flags
- Daily nutrition tip in chosen language
- NGO notices and announcements
- Settings: change language, toggle reminder preference

### Admin dashboard (desktop)
- Overview: total children, parents, meals today, active reminders
- Log daily meals per child with nutritional quality flag
- Add new children & register their parents
- Post notices in all 3 languages
- Toggle reminder preference per parent

---

## 🛠 Tech stack

| Layer    | Technology |
|----------|-----------|
| Frontend | React 18, React Router, i18next, bcryptjs |
| Storage  | Browser localStorage (no external DB) |
| Auth     | bcryptjs password hashing (in-browser) |
| Hosting  | Vercel (static / CDN) |

---

## Team
Riya Sangam · Anushka Salunke · Jiya Patil · Bhargavi Patil  
B.Sc. IT Semester IV · Vidyalankar School of Information Technology · 2025–2026  
Community Engagement Project — Bright Future India, Mumbai
